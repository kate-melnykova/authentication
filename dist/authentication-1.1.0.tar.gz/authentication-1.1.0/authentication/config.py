"""
    authentication.config
    ~~~~~~~~~~~~
    Implements the configuration related objects.
"""
