"""
    authentication.config
    ~~~~~~~~~~~~
    Implements the configuration related objects.
"""
UPLOAD_FOLDER='/media'
ALLOWED_PHOTO_EXTENSIONS=['jpg']
