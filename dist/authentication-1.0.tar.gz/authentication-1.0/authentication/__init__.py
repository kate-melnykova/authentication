x = 1

def foo():
    print('Hello world!')