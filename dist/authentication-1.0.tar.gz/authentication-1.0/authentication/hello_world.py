from flask import Flask

def foo():
    print('Hello world! '*3)